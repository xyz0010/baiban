export default (sentryErrorId) => `
### Scene content

\`\`\`
Paste scene content here
\`\`\`

### Sentry Error ID

${sentryErrorId}
`;
