# @excalidraw/common

## Install

```bash
npm install @excalidraw/common
```

If you prefer Yarn over npm, use this command to install the Excalidraw utils package:

```bash
yarn add @excalidraw/common
```

With PNPM, similarly install the package with this command:

```bash
pnpm add @excalidraw/common
```
